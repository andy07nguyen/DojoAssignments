USE mydbconnection;
SELECT * FROM users;
INSERT INTO users(first_name, last_name)
VALUE ("andy", "nguyen");

