puts 'I am in the mammal file'

class Mammal
  def initialize
    @health = 150
  end

  def display_health
  puts "HEALTH: #{@health}"
  end
end
