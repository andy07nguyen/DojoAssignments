puts 'I am in the mammal file'

class Mammal
  # previous code removed for brevity
  def initialize
    @health = 150
  end

  def display_health
    puts "HEALTH: #{@health}"
  end

end
