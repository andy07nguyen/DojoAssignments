# Challenge
# Try the following methods at least once either on a separate Ruby file or on irb.
# .at or .fetch .delete .reverse .length .sort .slice .shuffle .join .insert values_at() -> returns an array with values specified in the param
# e.g. a = %w{cat dog bear}; puts a.values_at(1,2).join(' and ') #=> "dog and bear"


a = ["Matz", "Guido", "Dojo", "Choi", "John"]
b = [5,6,9,1,2,4,7,8,10]
c = ["Dojo", 9]

a = %w{Matz Guido Dojo Choi John}

# RETURNS THE FIRST VALUE OR OTH  INDEX OF THE ARRAY.
# puts a[0]
# puts a[1]
#
# puts b.class
# puts.b.shuffle.join("-")
#
# puts a.to_s

# puts a + b

# x = a + b
# x = (a+b)-c

# puts x.to_s

# puts a.shuffle

# puts a.shuffle.join(', ')

# a.delete("Choi")

puts a

puts "Length of a is #{a.length}"
