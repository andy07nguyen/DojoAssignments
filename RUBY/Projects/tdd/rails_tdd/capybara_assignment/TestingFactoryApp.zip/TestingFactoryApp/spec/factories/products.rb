FactoryGirl.define do
  factory :product do
    name "MyString"
    user # nil value removed
  end
end
