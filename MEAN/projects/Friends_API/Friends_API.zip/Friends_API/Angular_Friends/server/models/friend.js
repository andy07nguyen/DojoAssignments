console.log('FROM FRIENDS MODELS JS:');
var mongoose = require('mongoose');
