console.log('FROM FRIENDS CONTROLLER JS:');
module.exports = {
  index: function(req,res){
    //your code here
    res.json({placeholder:'index'});
  },
  create: function(req,res){
    //your code here
    res.json({placeholder:'create'});
  },
  update: function(req,res){
    //your code here
    res.json({placeholder:'update'});
  },
  delete: function(req,res){
    //your code here
    res.json({placeholder:'delete'});
  },
  show: function(req,res){
    //your code here
    res.json({placeholder:'show'});
  }
}
