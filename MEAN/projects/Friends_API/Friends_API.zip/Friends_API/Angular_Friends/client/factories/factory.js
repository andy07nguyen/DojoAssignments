myApp.factory('friendsFactory', function (){

});
