console.log('FROM FRIENDS MODELS JS:');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// FriendSchema:
var FriendSchema = new mongoose.Schema({
  name: String,
  question: String,
  options: [{
    value: String, vote:{type:Number, default: 0}
  }],
  _user_id: {type: Schema.Types.ObjectId, ref: 'Login'}
}, { timestamps: true });

mongoose.model('Friend', FriendSchema);

// LoginSchema:
var LoginSchema = new mongoose.Schema({
  name: String
}, { timestamps: true });

mongoose.model('Login', LoginSchema);
