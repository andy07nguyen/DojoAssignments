console.log('FROM FRIENDS MODELS JS:');
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var date = Date()

var FriendSchema = new mongoose.Schema({
  name: String,
  question: String,
  option1: String,
  option2: String,
  option3: String,
  option4: String,
  count: Number
});

mongoose.model('Friend', FriendSchema);
