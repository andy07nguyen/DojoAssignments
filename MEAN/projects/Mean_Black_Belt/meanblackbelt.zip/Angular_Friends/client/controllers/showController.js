myApp.controller('showController', ['$scope', 'usersFactory', '$routeParams', '$location', function ($scope, usersFactory, $routeParams, $location){
  $scope.showUser = [];

  // CALLBACK: SHOW USER
  function setUser(userdata){
    console.log("CAllBACK setUser: ", userdata)
    $scope.showUser = userdata;
  }

  // SHOW - FUNCTION
  $scope.show = function(data) {
    usersFactory.show(data._id, setUser);
  }

}]);
