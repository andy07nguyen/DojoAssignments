myApp.controller('usersController', ['$scope', 'usersFactory', '$routeParams', '$location', function ($scope, usersFactory, $routeParams, $location){
  // console.log("ROUTE PARAMS: ", $routeParams, $routeParams.show);
  $scope.users = [];
  $scope.showUser = [];
  // CALLBACK:
  function setData(data){
    // console.log("CAllBACK: ", data)
    $scope.users = data;
    $scope.item = {};
  }
  // CALLBACK: SHOW USER
  function setUser(userdata){
    console.log("CAllBACK setUser: ", userdata)
    $scope.users = userdata;
  }
  // INDEX: SHOW - FUNCTION
  usersFactory.index(setData);
  // ADD - FUNCTION
  $scope.add = function(){
    // console.log("usersController: ", $scope.item)
    usersFactory.create($scope.item, setData);
    $scope.item = {};
    $location.url('/dashboard');
  }
  // REMOVE - FUNCTION
  $scope.remove = function(data){
    // console.log("usersController: ", data._id)
    usersFactory.delete(data._id, setData);
    usersFactory.index(setData);
  }
  // // SHOW - FUNCTION
  $scope.show = function(data) {
    usersFactory.show(data._id, setUser);
  }
  // usersFactory.show($routeParams.show, setUser);
  // console.log("usersController: ", $routeParams.show)

  //VOTE - FUNCTION
  $scope.vote = function(data) {
    usersFactory.vote(data, 1, setUser)
  }




// *****************
  // LOGIN - FUNCTION
  $scope.login = function(){
    // usersFactory.login($scope.item, setData);
    // console.log("usersController: ", $scope.item)
    $location.url('/dashboard');
  }


}]);
