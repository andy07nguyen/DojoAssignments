myApp.factory('usersFactory', ['$http', function ($http){
  var usersList = [
    {
      first: "Andy",
      last: "Nguyen",
      date: "yay"
    }
  ];
  var showList = [
    {
      option1: "hello",
      option2: "world",
    }
  ];
  var factory = {};
  // INDEX: SHOW
  factory.index = function(callback){
    $http.get('/friends').then(function(returned_data){
    // console.log(returned_data.data)
    callback(returned_data.data);
    })
  };
  // CREATE:
  factory.create = function(data, callback){
    // console.log("usersFactory: ", data)
    $http.post('/friends/new', data).then(function(returned_data){
      // console.log("DATA FROM SERVER CONTROLLER: )", returned_data.data);
      usersList.push(returned_data.data)
      // callback(returned_data.data)
      callback(usersList)
    })
  };
  // DELETE:
  factory.delete = function(id, callback){
    // console.log("usersFactory: ", id)
    $http.delete('/friends/'+id).then(function(returned_data){
      // console.log("DATA FROM SERVER CONTROLLER: )", returned_data.data);
      callback(returned_data.data)
    })
  };
  //SHOW:
  factory.show = function(id, callback){
    // console.log("usersFactory: ", id)
    $http.get('/friends/'+id).then(function(returned_data){
      // console.log("DATA FROM SERVER CONTROLLER: )", returned_data.data);
      showList.push(returned_data.data);
      callback(showList)
      // callback(returned_data.data);
      // }
    })
  };
  // VOTE:
  factory.vote = function(data, count, callback){
    if(typeof count == Number){
      for(var i = 0; i < showList[i].length; i++){
        if(showList[i]._id == data._id){
          if(showList[i].count + count > 0){
            showList[i].count = showList[i].count + count;
          } else {
            showList[i].count = 0;
          }
        }
      }
    }
    callback(showList)
  };


// *****************
  //LOGIN:
  factory.login = function(data, callback){
    $http.post('/friends/login', data).then(function(returned_data){
      // console.log("DATA FROM SERVER CONTROLLER: )", returned_data.data);
    })
  };

  return factory
}]);
