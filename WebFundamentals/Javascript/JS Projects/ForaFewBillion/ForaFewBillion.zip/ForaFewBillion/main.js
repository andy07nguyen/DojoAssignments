var pennies = 0.01

for(var i = 0; i <= 30; i++){
	console.log(pennies)
	pennies = 2 * pennies;
}