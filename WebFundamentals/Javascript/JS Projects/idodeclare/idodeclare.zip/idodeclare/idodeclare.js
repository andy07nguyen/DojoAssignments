var num1 = 11;
var num2 = 202;
var num3 = 3;
var num4 = -4;

var word1 = "hello";
var word2 = "hi";
var word3 = "coding";

var answer1 = false;
var answer2 = true;

var x


console.log(num1, num2, num3, num4, word1, word2, word3, answer1, answer2, x)
