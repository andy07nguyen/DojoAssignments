function fancy(){
	var arr = ["James", "Jill", "Jane", "jack"]

	for(var i = 0; i < arr.length; i++){
		console.log(i + " -> " + arr[i])
	}
}

fancy()






// function take(arr, symbol){

// 	for(var i = 0; i < arr.length; i++){
// 		console.log(i + symbol + arr[i]);
// 	}
// }

// var arr = ["jack", "jill","jane", "james"];

// take(arr);